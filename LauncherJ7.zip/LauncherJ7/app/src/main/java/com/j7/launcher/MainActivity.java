package com.j7.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.RelativeSizeSpan;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    static final int BG = 0xFF0E1320, BG2 = 0xFF161D30, FG = 0xFFEEF1F8, DIM = 0xFF8892AA, ACC = 0xFF4DA3FF;
    static final String[][] TABS = {
            {"fav", "★", "Favoritas"}, {"all", "▦", "Todas"}, {"soc", "💬", "Social"},
            {"med", "🎵", "Medios"}, {"jue", "🎮", "Juegos"}, {"uti", "🛠", "Útiles"}};
    static final String[] SOC = {"whatsapp", "facebook", "instagram", "telegram", "twitter", "messag", "mms", "dialer", "phone", "contacts", "chrome", "browser", "mail", "tiktok", "snapchat", "messenger", "discord"};
    static final String[] MED = {"youtube", "music", "gallery", "camera", "photo", "video", "spotify", "player", "netflix", "radio"};

    static class App { String pkg, cls, label, cat; }

    final List<App> all = new ArrayList<>(), shown = new ArrayList<>();
    final LruCache<String, Drawable> icons = new LruCache<>(60);
    SharedPreferences sp;
    PackageManager pm;
    float dens;
    String tab = "all";
    boolean dirty = true;
    GridView grid;
    EditText q;
    TextView title, emptyTv;
    LinearLayout tabBar, banner;
    BaseAdapter adapter;
    final BroadcastReceiver pkgRx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { dirty = true; }
    };

    int dp(float v) { return Math.round(v * dens); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    String id(App a) { return a.pkg + "/" + a.cls; }
    String dn(App a) { return sp.getString("n:" + id(a), a.label); }
    Set<String> set(String k) { return new HashSet<>(sp.getStringSet(k, new HashSet<String>())); }
    void saveSet(String k, Set<String> s) { sp.edit().putStringSet(k, s).apply(); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("j7", 0);
        pm = getPackageManager();
        dens = getResources().getDisplayMetrics().density;
        tab = sp.getString("tab", "all");
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(16), dp(14), dp(16), dp(6));
        q = new EditText(this);
        q.setHint("Buscar app");
        q.setHintTextColor(DIM);
        q.setTextColor(FG);
        q.setTextSize(15);
        q.setSingleLine(true);
        q.setImeOptions(EditorInfo.IME_ACTION_GO);
        q.setPadding(dp(18), 0, dp(18), 0);
        q.setBackground(round(BG2, 21));
        top.addView(q, new LinearLayout.LayoutParams(0, dp(42), 1));
        TextView gear = new TextView(this);
        gear.setText("⚙");
        gear.setTextSize(18);
        gear.setTextColor(DIM);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(round(BG2, 21));
        gear.setOnClickListener(v -> settings());
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(42), dp(42));
        gp.leftMargin = dp(10);
        top.addView(gear, gp);
        root.addView(top);

        title = new TextView(this);
        title.setTextSize(13);
        title.setTextColor(DIM);
        title.setPadding(dp(22), dp(6), 0, dp(2));
        root.addView(title);

        FrameLayout mid = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(sp.getInt("cols", 4));
        grid.setVerticalSpacing(dp(16));
        grid.setPadding(dp(8), dp(10), dp(8), dp(10));
        grid.setClipToPadding(false);
        grid.setSelector(new ColorDrawable(0));
        grid.setVerticalScrollBarEnabled(false);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        emptyTv = new TextView(this);
        emptyTv.setTextColor(DIM);
        emptyTv.setTextSize(14);
        emptyTv.setGravity(Gravity.CENTER);
        emptyTv.setPadding(dp(30), 0, dp(30), 0);
        mid.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        mid.addView(emptyTv, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        grid.setEmptyView(emptyTv);
        root.addView(mid, new LinearLayout.LayoutParams(-1, 0, 1));

        adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup p) {
                if (v == null) {
                    LinearLayout l = new LinearLayout(MainActivity.this);
                    l.setOrientation(LinearLayout.VERTICAL);
                    l.setGravity(Gravity.CENTER_HORIZONTAL);
                    l.setPadding(dp(2), 0, dp(2), 0);
                    l.addView(new ImageView(MainActivity.this), new LinearLayout.LayoutParams(dp(52), dp(52)));
                    TextView t = new TextView(MainActivity.this);
                    t.setTextSize(11.5f);
                    t.setTextColor(FG);
                    t.setSingleLine(true);
                    t.setEllipsize(TextUtils.TruncateAt.END);
                    t.setGravity(Gravity.CENTER);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                    lp.topMargin = dp(6);
                    l.addView(t, lp);
                    v = l;
                }
                LinearLayout l = (LinearLayout) v;
                App a = shown.get(i);
                ((ImageView) l.getChildAt(0)).setImageDrawable(icon(a));
                TextView t = (TextView) l.getChildAt(1);
                t.setText(dn(a));
                t.setVisibility(sp.getBoolean("labels", true) ? View.VISIBLE : View.GONE);
                return v;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, i, idx) -> launch(shown.get(i)));
        grid.setOnItemLongClickListener((p, v, i, idx) -> { menu(shown.get(i)); return true; });

        banner = new LinearLayout(this);
        banner.setGravity(Gravity.CENTER_VERTICAL);
        banner.setBackgroundColor(BG2);
        banner.setPadding(dp(14), dp(10), dp(14), dp(10));
        TextView msg = new TextView(this);
        msg.setText("Demo: así se ve. Para usarlo en lugar de One UI, tocá Activar y elegí Launcher J7 → Siempre.");
        msg.setTextSize(12.5f);
        msg.setTextColor(FG);
        banner.addView(msg, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = new TextView(this);
        go.setText("Activar");
        go.setTypeface(null, Typeface.BOLD);
        go.setTextColor(0xFF06101F);
        go.setBackground(round(ACC, 16));
        go.setPadding(dp(16), dp(8), dp(16), dp(8));
        go.setOnClickListener(v -> activate());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.leftMargin = dp(10);
        banner.addView(go, bp);
        root.addView(banner);

        tabBar = new LinearLayout(this);
        tabBar.setBackgroundColor(0xFF0B101C);
        tabBar.setPadding(dp(6), dp(6), dp(6), dp(8));
        root.addView(tabBar);

        setContentView(root);

        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) { refresh(); }
        });
        q.setOnEditorActionListener((v, act, ev) -> {
            if (!shown.isEmpty() && q.getText().length() > 0) { launch(shown.get(0)); q.setText(""); }
            return true;
        });

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgRx, f);
        updateTabs();
    }

    @Override protected void onResume() {
        super.onResume();
        if (dirty) load();
        refresh();
        banner.setVisibility(isDefault() ? View.GONE : View.VISIBLE);
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        q.setText("");
        grid.setSelection(0);
    }

    @Override public void onBackPressed() {
        if (q.getText().length() > 0) q.setText("");
    }

    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        icons.evictAll();
    }

    @Override protected void onDestroy() {
        unregisterReceiver(pkgRx);
        super.onDestroy();
    }

    void load() {
        Intent m = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        all.clear();
        for (ResolveInfo ri : pm.queryIntentActivities(m, 0)) {
            if (ri.activityInfo.packageName.equals(getPackageName())) continue;
            App a = new App();
            a.pkg = ri.activityInfo.packageName;
            a.cls = ri.activityInfo.name;
            a.label = String.valueOf(ri.loadLabel(pm));
            a.cat = cat(ri.activityInfo.applicationInfo);
            all.add(a);
        }
        icons.evictAll();
        dirty = false;
    }

    String cat(ApplicationInfo ai) {
        if (Build.VERSION.SDK_INT >= 26) {
            switch (ai.category) {
                case ApplicationInfo.CATEGORY_GAME: return "jue";
                case ApplicationInfo.CATEGORY_SOCIAL:
                case ApplicationInfo.CATEGORY_NEWS: return "soc";
                case ApplicationInfo.CATEGORY_AUDIO:
                case ApplicationInfo.CATEGORY_VIDEO:
                case ApplicationInfo.CATEGORY_IMAGE: return "med";
                default: break;
            }
        }
        if ((ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0) return "jue";
        String p = ai.packageName.toLowerCase(Locale.ROOT);
        for (String k : SOC) if (p.contains(k)) return "soc";
        for (String k : MED) if (p.contains(k)) return "med";
        return "uti";
    }

    Drawable icon(App a) {
        String k = id(a);
        Drawable d = icons.get(k);
        if (d == null) {
            try { d = pm.getActivityIcon(new ComponentName(a.pkg, a.cls)); }
            catch (Exception e) { d = pm.getDefaultActivityIcon(); }
            icons.put(k, d);
        }
        return d;
    }

    void refresh() {
        String s = q.getText().toString().trim().toLowerCase(Locale.getDefault());
        Set<String> fav = set("favs"), hid = set("hid");
        shown.clear();
        for (App a : all) {
            String k = id(a);
            if (hid.contains(k)) continue;
            if (!s.isEmpty()) { if (!dn(a).toLowerCase(Locale.getDefault()).contains(s)) continue; }
            else if (tab.equals("fav")) { if (!fav.contains(k)) continue; }
            else if (!tab.equals("all") && !a.cat.equals(tab)) continue;
            shown.add(a);
        }
        Collections.sort(shown, (x, y) -> dn(x).compareToIgnoreCase(dn(y)));
        String t = "";
        for (String[] x : TABS) if (x[0].equals(tab)) t = x[2];
        title.setText(s.isEmpty() ? t : "Resultados");
        emptyTv.setText(!s.isEmpty() ? "No hay apps con ese nombre."
                : tab.equals("fav") ? "Todavía no tenés favoritas.\nMantené presionada una app para agregarla acá."
                : "No hay apps en esta categoría.");
        adapter.notifyDataSetChanged();
    }

    void updateTabs() {
        tabBar.removeAllViews();
        for (String[] t : TABS) {
            TextView v = new TextView(this);
            SpannableString ss = new SpannableString(t[1] + "\n" + t[2]);
            ss.setSpan(new RelativeSizeSpan(1.8f), 0, t[1].length(), 0);
            v.setText(ss);
            v.setTextSize(10.5f);
            v.setGravity(Gravity.CENTER);
            v.setPadding(0, dp(5), 0, dp(5));
            boolean on = t[0].equals(tab);
            v.setTextColor(on ? ACC : DIM);
            if (on) v.setBackground(round(BG2, 12));
            v.setOnClickListener(x -> {
                tab = t[0];
                sp.edit().putString("tab", tab).apply();
                q.setText("");
                updateTabs();
                refresh();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.leftMargin = lp.rightMargin = dp(2);
            tabBar.addView(v, lp);
        }
    }

    void launch(App a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(a.pkg, a.cls)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
        } catch (Exception e) {
            dirty = true;
            Toast.makeText(this, "No se pudo abrir la app", Toast.LENGTH_SHORT).show();
        }
    }

    AlertDialog.Builder dlg() { return new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert); }

    void menu(App a) {
        final String k = id(a);
        final boolean f = set("favs").contains(k);
        String[] items = {f ? "Quitar de favoritas" : "Agregar a favoritas", "Renombrar", "Ocultar", "Desinstalar"};
        dlg().setTitle(dn(a)).setItems(items, (d, w) -> {
            if (w == 0) {
                Set<String> s = set("favs");
                if (f) s.remove(k); else s.add(k);
                saveSet("favs", s);
                refresh();
            } else if (w == 1) {
                rename(a);
            } else if (w == 2) {
                Set<String> h = set("hid");
                h.add(k);
                saveSet("hid", h);
                Set<String> fs = set("favs");
                fs.remove(k);
                saveSet("favs", fs);
                refresh();
                Toast.makeText(this, "Oculta. Se muestra desde Ajustes", Toast.LENGTH_SHORT).show();
            } else {
                startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
            }
        }).show();
    }

    void rename(App a) {
        EditText e = new EditText(this);
        e.setText(dn(a));
        e.setSelectAllOnFocus(true);
        dlg().setTitle("Renombrar").setView(e).setPositiveButton("Guardar", (d, w) -> {
            String v = e.getText().toString().trim();
            SharedPreferences.Editor ed = sp.edit();
            if (v.isEmpty() || v.equals(a.label)) ed.remove("n:" + id(a)); else ed.putString("n:" + id(a), v);
            ed.apply();
            refresh();
        }).setNegativeButton("Cancelar", null).show();
    }

    void settings() {
        int cols = sp.getInt("cols", 4);
        boolean lab = sp.getBoolean("labels", true);
        String[] items = {"Columnas: " + cols + " (cambiar)", "Nombres de apps: " + (lab ? "sí" : "no") + " (cambiar)",
                "Apps ocultas (" + set("hid").size() + ")"};
        dlg().setTitle("Ajustes").setItems(items, (d, w) -> {
            if (w == 0) {
                int c = cols == 4 ? 5 : 4;
                sp.edit().putInt("cols", c).apply();
                grid.setNumColumns(c);
            } else if (w == 1) {
                sp.edit().putBoolean("labels", !lab).apply();
                adapter.notifyDataSetChanged();
            } else {
                hiddenDialog();
            }
        }).show();
    }

    void hiddenDialog() {
        Set<String> h = set("hid");
        final List<App> hs = new ArrayList<>();
        for (App a : all) if (h.contains(id(a))) hs.add(a);
        if (hs.isEmpty()) { Toast.makeText(this, "No ocultaste ninguna app", Toast.LENGTH_SHORT).show(); return; }
        String[] names = new String[hs.size()];
        for (int i = 0; i < names.length; i++) names[i] = dn(hs.get(i));
        dlg().setTitle("Tocá una app para mostrarla").setItems(names, (d, w) -> {
            Set<String> s = set("hid");
            s.remove(id(hs.get(w)));
            saveSet("hid", s);
            refresh();
        }).show();
    }

    boolean isDefault() {
        Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = pm.resolveActivity(h, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null && getPackageName().equals(ri.activityInfo.packageName);
    }

    void activate() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = getSystemService(RoleManager.class);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 1);
                    return;
                }
            }
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME));
            } catch (Exception e2) {
                Toast.makeText(this, "Abrí Ajustes > Aplicaciones > Apps predeterminadas > Pantalla de inicio", Toast.LENGTH_LONG).show();
            }
        }
    }
}
